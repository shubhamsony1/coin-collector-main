using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalGM
{
    public static bool randomizesine = true;
    public static float sinerange = 0;
    public static float sinespeed = 0;
}
